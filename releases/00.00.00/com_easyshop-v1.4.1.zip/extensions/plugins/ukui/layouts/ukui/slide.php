<?php
/**
 * @version        1.1.4
 * @package        plg_system_ukui
 * @author         JoomTech Team - http://www.joomtech.net/
 * @copyright      Copyright (C) 2015 - 2020 www.joomtech.net All Rights Reserved
 * @license        http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL
 */
defined('_JEXEC') or die;
include __DIR__ . '/accordion.php';
