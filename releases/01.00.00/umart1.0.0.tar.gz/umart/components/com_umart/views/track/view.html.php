<?php
/**
 
 
 
 
 
 */

use Umart\View\BaseView;

defined('_JEXEC') or die;

class UmartViewTrack extends BaseView
{

}
