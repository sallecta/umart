<?php
/**
 
 * @version     1.0.5
 
* @copyright   Copyright (C) 2015 - 2019 github.com/sallecta/umart All Rights Reserved.
 
 */
defined('_JEXEC') or die;

echo $this->getRenderer()->render('cart.empty');
