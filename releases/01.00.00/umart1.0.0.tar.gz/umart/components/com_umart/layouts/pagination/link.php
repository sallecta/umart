<?php
/**
 
 
 
 
 
 */
defined('_JEXEC') or die;

require UMART_COMPONENT_ADMINISTRATOR . '/layouts/pagination/link.php';
