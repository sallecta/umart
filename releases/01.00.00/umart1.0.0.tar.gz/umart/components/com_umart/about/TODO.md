
# Umart ToDo List

3. Uninstall Umart Menu on extension uninstall (warning: The alias shop is already being used by Shop menu item in the EasyShop Menu menu)
2. ~~Rebrand~~
1. ~~Upload sources~~
