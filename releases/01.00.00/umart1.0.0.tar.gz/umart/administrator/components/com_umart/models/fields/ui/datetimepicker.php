<?php
/**
 
 
 
 
 
 */

defined('_JEXEC') or die;

use Joomla\CMS\Form\FormHelper;

FormHelper::loadFieldClass('flatpicker');

class JFormFieldUI_DateTimePicker extends JFormFieldFlatPicker
{

}