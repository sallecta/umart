<?php
/**
 
 
 
 
 
 */
defined('_JEXEC') or die;

use Umart\Model\AdminModel;

class UmartModelTax extends AdminModel
{

}
