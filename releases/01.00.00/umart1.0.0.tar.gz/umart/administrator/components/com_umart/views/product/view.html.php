<?php
/**
 
 
 
 
 
 */

defined('_JEXEC') or die;

use Umart\View\ItemView;

class UmartViewProduct extends ItemView
{

}
