<?php
/**
 
 
 
 
 
 */

defined('_JEXEC') or die;

use Umart\View\ListView;

class UmartViewTags extends ListView
{

}
