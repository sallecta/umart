<?php
/**
 
 * @version     1.0.5
 * @Author      JoomTech Team
 * @copyright   Copyright (C) 2015 - 2019 github.com/sallecta/umart All Rights Reserved.
 
 */

defined('_JEXEC') or die;

use Umart\View\ListView;

class UmartViewEmails extends ListView
{

}
