<?php
/**
 
 
 
 
 
 */

defined('_JEXEC') or die;

use Umart\View\ListView;

class UmartViewTaxes extends ListView
{

}
