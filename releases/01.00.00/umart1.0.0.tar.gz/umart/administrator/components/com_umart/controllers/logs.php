<?php

/**
 
 
 
 
 
 */
defined('_JEXEC') or die;

use Umart\Controller\AdminController;

class UmartControllerLogs extends AdminController
{

}
