<?php
/**
 
 * @version     1.0.5
 * @Author      JoomTech Team
 
 
 */
defined('_JEXEC') or die;

use Umart\Controller\FormController;

class UmartControllerTax extends FormController
{

}
