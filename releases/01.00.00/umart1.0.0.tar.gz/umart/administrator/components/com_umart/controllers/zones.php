<?php
/**
 
 
 
 
 
 */
defined('_JEXEC') or die;
use Umart\Controller\AdminController;

class UmartControllerZones extends AdminController
{

}
