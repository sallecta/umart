<?php

/**
 *  @package     com_umart
 *  @version     1.0.5
 *  @Author      JoomTech Team
* @copyright   Copyright (C) 2015 - 2019 github.com/sallecta/umart All Rights Reserved.
 *  @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
defined('_JEXEC') or die;
use Umart\Controller\AdminController;

class UmartControllerDiscounts extends AdminController
{

}
