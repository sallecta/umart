<?php
/**
 
 
 
 
 
 */
defined('_JEXEC') or die;
use Umart\Controller\FormController;

class UmartControllerZone extends FormController
{

}
