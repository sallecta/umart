<?php
/**
 * @version        1.1.4
 * @package        plg_system_umartukui
 * @author         JoomTech Team - http://github.com/sallecta/umart/
 * @copyright      Copyright (C) 2015 - 2020 github.com/sallecta/umart All Rights Reserved
 * @license        http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL
 */
defined('_JEXEC') or die;
include __DIR__ . '/accordion.php';
