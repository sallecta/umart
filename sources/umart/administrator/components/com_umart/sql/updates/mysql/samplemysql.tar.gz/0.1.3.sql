ALTER TABLE `#__umart_taxes` DROP COLUMN `zone_country_id`;
ALTER TABLE `#__umart_taxes` DROP COLUMN `zone_state_id`;
ALTER TABLE `#__umart_taxes` ADD COLUMN `vendor_id` INT(10) UNSIGNED NOT NULL DEFAULT '0' AFTER `flat`;