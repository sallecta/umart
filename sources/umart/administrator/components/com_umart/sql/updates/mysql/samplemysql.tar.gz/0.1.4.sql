ALTER TABLE `#__umart_methods` ADD COLUMN `vendor_id` INT(10) UNSIGNED NOT NULL DEFAULT '0' AFTER `state`;
ALTER TABLE `#__umart_emails` ADD COLUMN `vendor_id` INT(10) UNSIGNED NOT NULL DEFAULT '0' AFTER `state`;
ALTER TABLE `#__umart_discounts` ADD COLUMN `vendor_id` INT(10) UNSIGNED NOT NULL DEFAULT '0' AFTER `state`;
ALTER TABLE `#__umart_customfields` ADD COLUMN `vendor_id` INT(10) UNSIGNED NOT NULL DEFAULT '0' AFTER `state`;
ALTER TABLE `#__umart_orders` ADD COLUMN `vendor_id` INT(10) UNSIGNED NOT NULL DEFAULT '0' AFTER `state`;
ALTER TABLE `#__umart_orders` ADD COLUMN `parent_id` INT(10) UNSIGNED NOT NULL DEFAULT '0' AFTER `vendor_id`;
ALTER TABLE `#__umart_logs` DROP COLUMN `zone_country`;
ALTER TABLE `#__umart_logs` DROP COLUMN `zone_state`;